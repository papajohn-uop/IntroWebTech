const vouna = [
    [
        "Άνω Χώρα Ναυπακτίας", 
        './img/Ano_Hora.jpg'
    ],
    [
        "Καλαρύτες, στα Τζουμέρκα",
        './img/Kalarytes.jpg'
    ],
    [
        "Φαράγγι Πάνταβρέχει, Ευρυτανία",
        './img/Pantavrehi.jpg'
    ],
    [
        "Αθανάσιος Διάκος, Ορεινή Φωκίδα",
        './img/Athansios_Diakos.jpg', 
    ],
    [
        "Πάρνηθα στην Αττική",
        './img/Parnitha.jpg',
    ],
    [
        "Αρκουδόρεμα, στη Βάλια Κάλντα, Πίνδος",
        './img/ValiaCalda_Arkoudorema.jpg'
    ],
    [
        "Υμητός, Αττική, Μονή Καισαριανής",
        './img/Ymhtos.jpg'
    ],
    [
        "Όρος Φλέγκας, Πίνδος",
        './img/MountFlegkas.jpg'
    ],
    [
        "Όρος Παναχαϊκό, Αχαΐα",
        './img/Panhahaiko.jpg'
    ],
    [
        "Βαρδούσια, Φωκίδα",
        './img/Vardousia.jpg'
    ],
    [
        "Όρος Χελμός, Αχαία",
        './img/Helmos.jpg',
    ],
    [
        "Μετέωρα, Θεσσαλία",
        './img/Meteora.jpg'
    ],
    [
        "Μαίναλο, Αρκαδία",
        './img/Menalo.jpg'
    ],
    [
        "Ορος Οίτη, Φθιώτιδα",
        './img/Oith.jpg'
    ],
    [
        "Συράκο, Τζουμέρκα",
        './img/Syrako.jpg'
    ],
    [
        "Ο καταράκτης του Ερύμανθου, Αχαϊα",
        './img/Erymanthos_kataraktis.jpg'
    ]
]